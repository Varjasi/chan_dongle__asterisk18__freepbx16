/*
   Copyright (C) 2010 bg <bg_one@mail.ru>
*/
#ifndef CHAN_DONGLE_CLI_H_INCLUDED
#define CHAN_DONGLE_CLI_H_INCLUDED

#include "export.h"			/* EXPORT_DECL EXPORT_DEF */

EXPORT_DECL void cli_register();
EXPORT_DECL void cli_unregister();

#endif /* CHAN_DONGLE_CLI_H_INCLUDED */
